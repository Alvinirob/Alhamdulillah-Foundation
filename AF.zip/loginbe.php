<?php
session_start();
require_once  "logincon.php";

$message = "";
$role = "";

if (isset($_POST["submit"]))
{
	$user = $_POST["username"];
	$pass = $_POST["password"];

	$query = "SELECT * FROM login WHERE user = '$username' AND pass = '$password'";

	$result = mysqli_query($conn,$query);

	if(mysqli_num_rows($result)>0)
	{
		while($row = mysqli_fetch_assoc($result))
		{
			if($row["role"] == "president")
			{
				$_SESSION['LoginUser'] = $row["user"];
				header('Location: president.php');
			}
			else 
			{
				$_SESSION['LoginUser'] = $row["user"];
				header('Location: cashier.php');
			}
			
		}
	}
	else
	{
		header('Location: index.php');
	}
 
}

?>